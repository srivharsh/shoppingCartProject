package com.cart.demo.shoppingCartDemo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cart.demo.model.Products;
import com.cart.demo.model.ShoppingCart;
import com.cart.demo.repo.ProductsRepository;
import com.cart.demo.repo.ShoppingCartRepository;

@SpringBootTest
public class ShoppingControllerTest {
	
	@Mock
	ProductsRepository productsRepository;
	
	@Mock
	ShoppingCartRepository shoppingCartRepository;
	
	@Autowired
	MockMvc mvc;
	
	@BeforeAll
	private void setup() {
		ShoppingCart shoppingCart=new ShoppingCart();
		Products product=new Products();
		product.setCategory("Mobile");
		product.setDescription("Mobile Phone");
		product.setPrice(1000.0);
		List<Products> productList=new ArrayList<>();
		productList.add(product);
		shoppingCart.setCountryCode("IN");
		shoppingCart.setCurrency("INR");
		shoppingCart.setProducts(productList);
	}
	
	
	@Test
	public void createShoppingCartTest() throws Exception {
		String uri = "/carts";
		   MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
		      .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		   int status = mvcResult.getResponse().getStatus();
		   assertEquals(200, status);
		//Mockito.when(shoppingCartRepository.saveAndFlush(shoppingCart)).thenReturn(shoppingCart);
	}
}
